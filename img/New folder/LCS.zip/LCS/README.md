![](http://i.giphy.com/KCh9Kkf2MILK0.gif)

# LCS - Louisville Cartoonist Society

Like to Website : https://cmbailey87.github.io/LCS/

This Repo is for Louisville Cartoonist Society Potential new replacement webpage

This is a project and potentially the new website for the Louisville cartoonist society.

The responsive design utilizes Bootstrap v4 using the CDN link to their CSS and Js .

Css media queries are also used where bootstrap couldn't be utilized

The code incorporates both vinilla JavaScript and jQuery code.

## Structure

The site is built mainly upon utilizing the Bootstrap 4 front end web design framework.
Many of the "pre-canned" styles have been modified with a Custom CSS style sheet.

## Responsiveness

the site is fully mobile device responsive.
aswell as responsive on larger screens.
The Anthology cover gallery and google calendar sections add a bit of user itneraction

###### under construction...
there is a custom form at the bottom of the page for users to subscribe to newsletters or contact the group via email.




## Jquery and Vanilla JavaScript

The site includes a bit of both jquery and Vanilla JavaScript.
implemented for the image overlay, The toggle for the google calendar and the image flip for the arrow on the google calendar.

//  ¯\_(ツ)_/¯
